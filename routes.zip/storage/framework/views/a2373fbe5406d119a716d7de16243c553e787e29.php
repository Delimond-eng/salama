<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
"message"=> "Il n'y a aucun élèment répertorié pour l'instant !"
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
"message"=> "Il n'y a aucun élèment répertorié pour l'instant !"
]); ?>
<?php foreach (array_filter(([
"message"=> "Il n'y a aucun élèment répertorié pour l'instant !"
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="flex items-center my-10">
    <div class="mx-auto text-center" id="empty">
        <div class="image-fit mx-auto h-16 w-16 flex-none">
            <img src="dist/images/search.svg" alt="icon">
        </div>
        <div class="mt-3">
            <div class="font-extrabold text-lg">
                Aucun résultat disponible !
            </div>
            <div class="mt-1 text-slate-500">
                <?php echo e($message); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Delimond\Documents\DEVFOLDER\BACKEND\salama\resources\views/components/empty-state.blade.php ENDPATH**/ ?>