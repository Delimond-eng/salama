<!-- END: Breadcrumb -->
<!-- BEGIN: Search -->
<div class="search intro-x relative mr-3 sm:mr-6">
    <div class="relative hidden sm:block">
    
    </div>
    <a class="relative text-slate-600 sm:hidden" href="#">
        <i data-tw-merge="" data-lucide="search" class="stroke-1.5 w-5 h-5 dark:text-slate-500"></i>
    </a>
</div>
<!-- END: Search  -->
<!-- BEGIN: Account Menu -->
<div data-tw-merge="" data-tw-placement="bottom-end" class="dropdown relative"><button
        data-tw-toggle="dropdown" aria-expanded="false"
        class="cursor-pointer image-fit zoom-in intro-x block h-8 w-8 overflow-hidden rounded-full shadow-lg"><img
            src="assets/images/fakers/profile-5.jpg" alt="Midone - Tailwind Admin Dashboard Template">
    </button>
    <div data-transition="" data-selector=".show"
        data-enter="transition-all ease-linear duration-150"
        data-enter-from="absolute !mt-5 invisible opacity-0 translate-y-1"
        data-enter-to="!mt-1 visible opacity-100 translate-y-0"
        data-leave="transition-all ease-linear duration-150"
        data-leave-from="!mt-1 visible opacity-100 translate-y-0"
        data-leave-to="absolute !mt-5 invisible opacity-0 translate-y-1"
        class="dropdown-menu absolute z-[9999] hidden">
        <div data-tw-merge=""
            class="dropdown-content rounded-md border-transparent p-2 shadow-[0px_3px_10px_#00000017] dark:border-transparent dark:bg-darkmode-600 mt-px w-56 bg-theme-1 text-white">
            <div class="p-2 font-medium font-normal">
                <div class="font-medium"><?php echo e(Auth::user()->name); ?></div>
                <div class="mt-0.5 text-xs text-white/70 dark:text-slate-500">
                   <?php echo e(Auth::user()->email); ?>

                </div>
            </div>
            <div class="h-px my-2 -mx-2 bg-slate-200/60 dark:bg-darkmode-400 bg-white/[0.08]">
            </div>
            <a
                class="cursor-pointer flex items-center p-2 transition duration-300 ease-in-out rounded-md hover:bg-slate-200/60 dark:bg-darkmode-600 dark:hover:bg-darkmode-400 dropdown-item hover:bg-white/5"><i
                    data-tw-merge="" data-lucide="user" class="stroke-1.5 mr-2 h-4 w-4"></i>
                Profile</a>
            
            <a
                class="cursor-pointer flex items-center p-2 transition duration-300 ease-in-out rounded-md hover:bg-slate-200/60 dark:bg-darkmode-600 dark:hover:bg-darkmode-400 dropdown-item hover:bg-white/5"><i
                    data-tw-merge="" data-lucide="help-circle" class="stroke-1.5 mr-2 h-4 w-4"></i>
                Assistance Technique</a>
            <div class="h-px my-2 -mx-2 bg-slate-200/60 dark:bg-darkmode-400 bg-white/[0.08]">
            </div>
            <a
                class="cursor-pointer flex items-center p-2 transition duration-300 ease-in-out rounded-md hover:bg-slate-200/60 dark:bg-darkmode-600 dark:hover:bg-darkmode-400 dropdown-item hover:bg-white/5"><i
                    data-tw-merge="" data-lucide="toggle-right" class="stroke-1.5 mr-2 h-4 w-4"></i>
                Déconnexion</a>
        </div>
    </div>
</div>
<!-- END: Account Menu --><?php /**PATH C:\Users\Delimond\Documents\DEVFOLDER\BACKEND\salama\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>