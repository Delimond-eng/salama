<!DOCTYPE html>

<html lang="en" class="light">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">
    <link href="assets/images/patrol.svg" rel="shortcut icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Icewall admin for weeding app">
    <meta name="keywords" content="Rapid Tech Property">
    <meta name="author" content="Gaston Delimond Dev">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Salama Plateforme</title>
    <!-- BEGIN: CSS Assets-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>" />
    <!-- END: CSS Assets-->
</head>
<!-- BEGIN: JS Assets-->
<body class="login">
    <?php echo $__env->yieldContent("content"); ?>
    <!-- BEGIN: Js assets -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/libs/toastify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/libs/pristine.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/libs/vue2.js')); ?>"></script>
    <?php echo $__env->yieldContent("scripts"); ?>
    <!-- END: JS Assets-->
</body>

</html>
<?php /**PATH C:\Users\Delimond\Documents\DEVFOLDER\BACKEND\patrolTag\resources\views/layouts/auth.blade.php ENDPATH**/ ?>