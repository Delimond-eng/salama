<!DOCTYPE html>

<html lang="en" class="light">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">
    <link href="assets/images/patrol.svg" rel="shortcut icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Icewall admin for weeding app">
    <meta name="keywords" content="Rapid Tech Property">
    <meta name="author" content="Gaston Delimond Dev">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="user-id" content="<?php echo e(Auth::user()->id); ?>">
    <title>Salama Plateforme</title>
    <!-- BEGIN: CSS Assets-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/js/libs/sweetalert2/sweetalert2.min.css')); ?>" />
    <!-- END: CSS Assets-->
</head>
<!-- BEGIN: JS Assets-->
<body class="main">
    <!-- BEGIN: Mobile Menu -->
    <?php echo $__env->make("components.mobile_menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Mobile Menu -->
    <!-- BEGIN: Top Bar -->
    <?php echo $__env->make("components.top_bar_fixed", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Top Bar -->

    


    <div class="wrapper">
        <div class="wrapper-box ">
            <!-- BEGIN: Side Menu -->
            <?php echo $__env->make("components.side_nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- END: Side Menu -->
            <!-- BEGIN: Content -->
            <?php echo $__env->yieldContent("content"); ?>
            <!-- END: Content -->
        </div>
    </div>


    <!-- BEGIN: Js assets -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/libs/toastify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/libs/pristine.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/libs/vue2.js')); ?>"></script>
    
    <script type="module" src="<?php echo e(asset("assets/js/scripts/talkiewalkie_controller.js")); ?>"></script>
    <?php echo $__env->yieldPushContent("scripts"); ?>
    <!-- END: JS Assets-->
</body>

</html>
<?php /**PATH C:\Users\Delimond\Documents\DEVFOLDER\BACKEND\patrolTag\resources\views/layouts/app.blade.php ENDPATH**/ ?>